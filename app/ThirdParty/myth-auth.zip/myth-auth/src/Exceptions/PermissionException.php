<?php namespace Myth\Auth\Exceptions;

class PermissionException extends \RuntimeException implements ExceptionInterface
{
}
